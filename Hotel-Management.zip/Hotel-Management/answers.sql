
-- HOTEL MANAGEMENT SYSTEM
-- QUESTIONS 1 TO 40 (FULLY SOLVED)

-- Q1
SELECT * FROM Payments WHERE PaymentMethod = 'UPI';

-- Q2
SELECT DISTINCT FirstName FROM Customers;

-- Q3
DELETE FROM Rooms WHERE Capacity = 1;

-- Q4
SELECT CONCAT(FirstName,' ',LastName,' - ',Phone) AS Customer_Details FROM Customers;

-- Q5
SELECT * FROM Bookings WHERE RoomID = 10;

-- Q6
SELECT * FROM Rooms WHERE Capacity > (SELECT AVG(Capacity) FROM Rooms);

-- Q7
CREATE VIEW Staff_Contact_Details AS
SELECT FirstName, LastName, Role, Phone FROM Staff;

-- Q8
SELECT * FROM Rooms WHERE RoomType='Suite' AND PricePerNight < 7000;

-- Q9
SELECT Email FROM Customers ORDER BY LastName;

-- Q10
SELECT CONCAT(FirstName,' ',LastName) AS Staff_Name FROM Staff;

-- Q11
SELECT CONCAT_WS(' | ',PaymentID,PaymentMethod,Amount,PaymentDate) FROM Payments;

-- Q12
SELECT * FROM Rooms ORDER BY PricePerNight DESC LIMIT 2;

-- Q13
SELECT BookingID, CONCAT(CheckInDate,' to ',CheckOutDate) FROM Bookings;

-- Q14
SELECT PaymentMethod, AVG(Amount) FROM Payments GROUP BY PaymentMethod;

-- Q15
SELECT City, COUNT(*) FROM Customers GROUP BY City HAVING COUNT(*) > 1;

-- Q16
SELECT * FROM Bookings WHERE TotalAmount > (SELECT AVG(TotalAmount) FROM Bookings);

-- Q17
SELECT * FROM Rooms ORDER BY RoomID DESC LIMIT 2;

-- Q18
SELECT * FROM Payments WHERE Amount < 1500;

-- Q19
SELECT CustomerID FROM Bookings GROUP BY CustomerID HAVING COUNT(*) > 5;

-- Q20
SELECT A.CustomerID, A.FirstName, A.City
FROM Customers A JOIN Customers B
ON A.City=B.City AND A.CustomerID<>B.CustomerID;

-- Q21
SELECT StaffID, SUM(TotalAmount) FROM Bookings GROUP BY StaffID;

-- Q22
SELECT * FROM Customers WHERE City='Mumbai';

-- Q23
SELECT * FROM Bookings ORDER BY TotalAmount ASC LIMIT 3;

-- Q24
INSERT INTO Rooms (RoomType,PricePerNight,Capacity) VALUES
('Deluxe',3000,2),('Suite',6500,4),('Family',5000,4),('Standard',2500,2),('Luxury',8000,3);

-- Q25
SELECT DISTINCT CustomerID FROM Bookings;

-- Q26
DELIMITER //
CREATE TRIGGER delete_payment_after_booking
AFTER DELETE ON Bookings
FOR EACH ROW
BEGIN
 DELETE FROM Payments WHERE BookingID = OLD.BookingID;
END;
//
DELIMITER ;

-- Q27
UPDATE Customers SET FirstName='Rahul' WHERE CustomerID=30;

-- Q28
SELECT * FROM Bookings ORDER BY CheckInDate;

-- Q29
SELECT * FROM Rooms WHERE Capacity > 2;

-- Q30
SELECT Email FROM Staff ORDER BY Role;

-- Q31
SELECT RoomID, COUNT(*) FROM Bookings GROUP BY RoomID;

-- Q32
SELECT * FROM Customers WHERE Email LIKE '%.com';

-- Q33
SELECT * FROM Rooms WHERE PricePerNight BETWEEN 3000 AND 6000;

-- Q34
SELECT * FROM Bookings WHERE YEAR(CheckInDate)=2024;

-- Q35
SELECT SUM(Amount) FROM Payments;

-- Q36
SELECT MAX(PricePerNight) FROM Rooms;

-- Q37
SELECT MIN(TotalAmount) FROM Bookings;

-- Q38
SELECT * FROM Customers WHERE Phone LIKE '9%';

-- Q39
SELECT * FROM Staff WHERE Role='Manager';

-- Q40
SELECT * FROM Rooms ORDER BY Capacity DESC;

-- Q41
SELECT COUNT(*) AS Total_Customers FROM Customers;

-- Q42
SELECT COUNT(*) AS Total_Rooms FROM Rooms;

-- Q43
SELECT COUNT(*) AS Total_Staff FROM Staff;

-- Q44
SELECT COUNT(*) AS Total_Bookings FROM Bookings;

-- Q45
SELECT COUNT(*) AS Total_Payments FROM Payments;

-- Q46
SELECT * FROM Customers WHERE FirstName LIKE 'A%';

-- Q47
SELECT * FROM Staff WHERE Phone LIKE '%55';

-- Q48
SELECT * FROM Rooms WHERE Capacity = 2;

-- Q49
SELECT * FROM Bookings
WHERE DATEDIFF(CheckOutDate, CheckInDate) > 3;

-- Q50
SELECT * FROM Customers
WHERE CustomerID NOT IN (SELECT CustomerID FROM Bookings);

-- Q51
SELECT * FROM Rooms
WHERE RoomID NOT IN (SELECT RoomID FROM Bookings);

-- Q52
SELECT * FROM Staff
WHERE StaffID NOT IN (SELECT StaffID FROM Bookings);

-- Q53
SELECT MAX(Amount) AS Highest_Payment FROM Payments;

-- Q54
SELECT AVG(PricePerNight) AS Average_Room_Price FROM Rooms;

-- Q55
SELECT SUM(TotalAmount) AS Total_Revenue FROM Bookings;

-- Q56
SELECT B.*
FROM Bookings B
JOIN Rooms R ON B.RoomID = R.RoomID
WHERE R.RoomType = 'Deluxe';

-- Q57
SELECT C.FirstName, C.LastName, B.BookingID
FROM Customers C
JOIN Bookings B ON C.CustomerID = B.CustomerID;

-- Q58
SELECT S.FirstName, S.LastName, COUNT(B.BookingID) AS Total_Bookings
FROM Staff S
LEFT JOIN Bookings B ON S.StaffID = B.StaffID
GROUP BY S.StaffID;

-- Q59
SELECT R.RoomType, COUNT(B.BookingID) AS Total_Bookings
FROM Rooms R
LEFT JOIN Bookings B ON R.RoomID = B.RoomID
GROUP BY R.RoomType;

-- Q60
SELECT C.FirstName, C.LastName, SUM(B.TotalAmount) AS Total_Spent
FROM Customers C
JOIN Bookings B ON C.CustomerID = B.CustomerID
GROUP BY C.CustomerID;




-- Q61
SELECT CustomerID, COUNT(*) AS Total_Bookings
FROM Bookings
GROUP BY CustomerID;

-- Q62
SELECT RoomID, AVG(TotalAmount) AS Avg_Revenue
FROM Bookings
GROUP BY RoomID;

-- Q63
SELECT StaffID, MAX(TotalAmount) AS Max_Booking
FROM Bookings
GROUP BY StaffID;

-- Q64
SELECT City, COUNT(*) AS Customers_Count
FROM Customers
GROUP BY City;

-- Q65
SELECT RoomType, AVG(PricePerNight) AS Avg_Price
FROM Rooms
GROUP BY RoomType;

-- Q66
SELECT *
FROM Bookings
WHERE TotalAmount = (SELECT MAX(TotalAmount) FROM Bookings);

-- Q67
SELECT *
FROM Payments
WHERE Amount = (SELECT MIN(Amount) FROM Payments);

-- Q68
SELECT *
FROM Customers
WHERE CustomerID IN (
    SELECT CustomerID FROM Bookings
);

-- Q69
SELECT *
FROM Staff
WHERE StaffID IN (
    SELECT StaffID FROM Bookings
);

-- Q70
SELECT *
FROM Rooms
WHERE RoomID IN (
    SELECT RoomID FROM Bookings
);

-- Q71
SELECT *
FROM Customers
WHERE City <> 'Delhi';

-- Q72
SELECT *
FROM Rooms
WHERE RoomType <> 'Standard';

-- Q73
SELECT *
FROM Staff
WHERE Role <> 'Cleaner';

-- Q74
SELECT *
FROM Payments
WHERE PaymentMethod <> 'Cash';

-- Q75
SELECT *
FROM Bookings
WHERE CheckOutDate > CURDATE();

-- Q76
SELECT *
FROM Customers
WHERE Email IS NOT NULL;

-- Q77
SELECT *
FROM Staff
WHERE Phone IS NOT NULL;

-- Q78
SELECT *
FROM Rooms
WHERE Capacity IS NOT NULL;

-- Q79
SELECT *
FROM Payments
WHERE PaymentDate IS NOT NULL;

-- Q80
SELECT *
FROM Bookings
WHERE CheckInDate IS NOT NULL;



-- Q81
SELECT COUNT(DISTINCT CustomerID) AS Unique_Customers
FROM Bookings;

-- Q82
SELECT COUNT(DISTINCT RoomID) AS Booked_Rooms
FROM Bookings;

-- Q83
SELECT COUNT(DISTINCT StaffID) AS Active_Staff
FROM Bookings;

-- Q84
SELECT *
FROM Customers
WHERE City IN ('Mumbai','Delhi','Pune');

-- Q85
SELECT *
FROM Rooms
WHERE PricePerNight > 5000;

-- Q86
SELECT *
FROM Staff
WHERE Role IN ('Manager','Receptionist');

-- Q87
SELECT *
FROM Payments
WHERE PaymentMethod IN ('UPI','Card');

-- Q88
SELECT *
FROM Bookings
WHERE MONTH(CheckInDate) = 1;

-- Q89
SELECT *
FROM Bookings
WHERE YEAR(CheckInDate) = 2025;

-- Q90
SELECT *
FROM Customers
WHERE LENGTH(Phone) = 10;

-- Q91
SELECT *
FROM Rooms
WHERE Capacity >= 3;

-- Q92
SELECT *
FROM Staff
WHERE Email LIKE '%@hotel.com';

-- Q93
SELECT *
FROM Payments
WHERE Amount BETWEEN 2000 AND 8000;

-- Q94
SELECT *
FROM Bookings
WHERE CheckOutDate < CURDATE();

-- Q95
SELECT *
FROM Customers
WHERE FirstName <> LastName;

-- Q96
SELECT *
FROM Rooms
WHERE RoomType LIKE '%Suite%';

-- Q97
SELECT *
FROM Staff
WHERE Role LIKE '%Manager%';

-- Q98
SELECT *
FROM Payments
WHERE PaymentMethod LIKE '%Pay%';

-- Q99
SELECT *
FROM Bookings
WHERE TotalAmount >= 10000;

-- Q100
SELECT *
FROM Customers
ORDER BY FirstName ASC;




-- Q101
SELECT RoomType, COUNT(*) AS Total_Rooms
FROM Rooms
GROUP BY RoomType;

-- Q102
SELECT Role, COUNT(*) AS Total_Staff
FROM Staff
GROUP BY Role;

-- Q103
SELECT PaymentMethod, SUM(Amount) AS Total_Collected
FROM Payments
GROUP BY PaymentMethod;

-- Q104
SELECT YEAR(CheckInDate) AS Year, COUNT(*) AS Total_Bookings
FROM Bookings
GROUP BY YEAR(CheckInDate);

-- Q105
SELECT MONTH(CheckInDate) AS Month, COUNT(*) AS Total_Bookings
FROM Bookings
GROUP BY MONTH(CheckInDate);

-- Q106
SELECT City, COUNT(*) AS Total_Customers
FROM Customers
GROUP BY City
HAVING COUNT(*) >= 2;

-- Q107
SELECT RoomID, COUNT(*) AS Booking_Count
FROM Bookings
GROUP BY RoomID
HAVING COUNT(*) > 1;

-- Q108
SELECT StaffID, COUNT(*) AS Booking_Count
FROM Bookings
GROUP BY StaffID
HAVING COUNT(*) >= 1;

-- Q109
SELECT CustomerID, SUM(TotalAmount) AS Amount_Spent
FROM Bookings
GROUP BY CustomerID
HAVING SUM(TotalAmount) > 10000;

-- Q110
SELECT RoomType, AVG(PricePerNight) AS Avg_Price
FROM Rooms
GROUP BY RoomType
HAVING AVG(PricePerNight) > 4000;

-- Q111
SELECT *
FROM Customers
WHERE CustomerID = (
    SELECT CustomerID
    FROM Bookings
    GROUP BY CustomerID
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

-- Q112
SELECT *
FROM Rooms
WHERE PricePerNight = (
    SELECT MAX(PricePerNight)
    FROM Rooms
);

-- Q113
SELECT *
FROM Staff
WHERE StaffID = (
    SELECT StaffID
    FROM Bookings
    GROUP BY StaffID
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

-- Q114
SELECT *
FROM Customers
WHERE CustomerID NOT IN (
    SELECT CustomerID FROM Bookings
);

-- Q115
SELECT *
FROM Rooms
WHERE RoomID NOT IN (
    SELECT RoomID FROM Bookings
);

-- Q116
SELECT *
FROM Staff
WHERE StaffID NOT IN (
    SELECT StaffID FROM Bookings
);

-- Q117
SELECT *
FROM Customers
WHERE City = (
    SELECT City
    FROM Customers
    GROUP BY City
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

-- Q118
SELECT *
FROM Rooms
WHERE Capacity = (
    SELECT MAX(Capacity)
    FROM Rooms
);

-- Q119
SELECT *
FROM Payments
WHERE Amount > (
    SELECT AVG(Amount)
    FROM Payments
);

-- Q120
SELECT *
FROM Bookings
WHERE TotalAmount = (
    SELECT MAX(TotalAmount)
    FROM Bookings
);



-- Q121
SELECT C.City, SUM(B.TotalAmount) AS City_Revenue
FROM Customers C
JOIN Bookings B ON C.CustomerID = B.CustomerID
GROUP BY C.City;

-- Q122
SELECT R.RoomType, SUM(B.TotalAmount) AS Revenue
FROM Rooms R
JOIN Bookings B ON R.RoomID = B.RoomID
GROUP BY R.RoomType;

-- Q123
SELECT S.Role, COUNT(B.BookingID) AS Total_Bookings
FROM Staff S
LEFT JOIN Bookings B ON S.StaffID = B.StaffID
GROUP BY S.Role;

-- Q124
SELECT C.CustomerID, C.FirstName, COUNT(B.BookingID) AS Booking_Count
FROM Customers C
LEFT JOIN Bookings B ON C.CustomerID = B.CustomerID
GROUP BY C.CustomerID;

-- Q125
SELECT R.RoomID, R.RoomType, COUNT(B.BookingID) AS Booking_Count
FROM Rooms R
LEFT JOIN Bookings B ON R.RoomID = B.RoomID
GROUP BY R.RoomID;

-- Q126
SELECT S.StaffID, S.FirstName, SUM(B.TotalAmount) AS Collection
FROM Staff S
JOIN Bookings B ON S.StaffID = B.StaffID
GROUP BY S.StaffID;

-- Q127
SELECT C.CustomerID, C.FirstName, SUM(B.TotalAmount) AS Total_Spent
FROM Customers C
JOIN Bookings B ON C.CustomerID = B.CustomerID
GROUP BY C.CustomerID
ORDER BY Total_Spent DESC;

-- Q128
SELECT R.RoomType, AVG(DATEDIFF(B.CheckOutDate, B.CheckInDate)) AS Avg_Stay
FROM Rooms R
JOIN Bookings B ON R.RoomID = B.RoomID
GROUP BY R.RoomType;

-- Q129
SELECT S.Role, AVG(B.TotalAmount) AS Avg_Revenue
FROM Staff S
JOIN Bookings B ON S.StaffID = B.StaffID
GROUP BY S.Role;

-- Q130
SELECT YEAR(CheckInDate) AS Year, SUM(TotalAmount) AS Revenue
FROM Bookings
GROUP BY YEAR(CheckInDate);

-- Q131
SELECT MONTH(CheckInDate) AS Month, SUM(TotalAmount) AS Revenue
FROM Bookings
GROUP BY MONTH(CheckInDate);

-- Q132
SELECT C.CustomerID, C.FirstName
FROM Customers C
WHERE EXISTS (
    SELECT 1 FROM Bookings B WHERE B.CustomerID = C.CustomerID
);

-- Q133
SELECT R.RoomID, R.RoomType
FROM Rooms R
WHERE EXISTS (
    SELECT 1 FROM Bookings B WHERE B.RoomID = R.RoomID
);

-- Q134
SELECT S.StaffID, S.FirstName
FROM Staff S
WHERE EXISTS (
    SELECT 1 FROM Bookings B WHERE B.StaffID = S.StaffID
);

-- Q135
SELECT C.CustomerID, C.FirstName
FROM Customers C
WHERE NOT EXISTS (
    SELECT 1 FROM Bookings B WHERE B.CustomerID = C.CustomerID
);

-- Q136
SELECT R.RoomID, R.RoomType
FROM Rooms R
WHERE NOT EXISTS (
    SELECT 1 FROM Bookings B WHERE B.RoomID = R.RoomID
);

-- Q137
SELECT S.StaffID, S.FirstName
FROM Staff S
WHERE NOT EXISTS (
    SELECT 1 FROM Bookings B WHERE B.StaffID = S.StaffID
);

-- Q138
SELECT *
FROM Bookings
WHERE TotalAmount BETWEEN 5000 AND 15000;

-- Q139
SELECT *
FROM Payments
WHERE PaymentDate BETWEEN '2024-01-01' AND '2024-12-31';

-- Q140
SELECT *
FROM Customers
WHERE LENGTH(FirstName) > 4;




-- Q141
SELECT C.CustomerID, C.FirstName, COUNT(B.BookingID) AS Booking_Count
FROM Customers C
JOIN Bookings B ON C.CustomerID = B.CustomerID
GROUP BY C.CustomerID
HAVING COUNT(B.BookingID) >= 2;

-- Q142
SELECT R.RoomType, SUM(B.TotalAmount) AS Revenue
FROM Rooms R
JOIN Bookings B ON R.RoomID = B.RoomID
GROUP BY R.RoomType
HAVING SUM(B.TotalAmount) > 20000;

-- Q143
SELECT S.StaffID, S.FirstName, SUM(B.TotalAmount) AS Total_Collection
FROM Staff S
JOIN Bookings B ON S.StaffID = B.StaffID
GROUP BY S.StaffID
HAVING SUM(B.TotalAmount) > 15000;

-- Q144
SELECT City, AVG(TotalAmount) AS Avg_Booking_Value
FROM Customers C
JOIN Bookings B ON C.CustomerID = B.CustomerID
GROUP BY City;

-- Q145
SELECT R.RoomID, R.RoomType
FROM Rooms R
WHERE PricePerNight > (
    SELECT AVG(PricePerNight) FROM Rooms
);

-- Q146
SELECT C.CustomerID, C.FirstName
FROM Customers C
WHERE CustomerID IN (
    SELECT CustomerID
    FROM Bookings
    WHERE TotalAmount > 10000
);

-- Q147
SELECT S.StaffID, S.FirstName
FROM Staff S
WHERE StaffID IN (
    SELECT StaffID
    FROM Bookings
    WHERE CheckInDate >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
);

-- Q148
SELECT *
FROM Bookings
WHERE DATEDIFF(CheckOutDate, CheckInDate) = (
    SELECT MAX(DATEDIFF(CheckOutDate, CheckInDate)) FROM Bookings
);

-- Q149
SELECT *
FROM Payments
WHERE Amount = (
    SELECT MAX(Amount) FROM Payments
);

-- Q150
SELECT *
FROM Customers
WHERE CustomerID = (
    SELECT CustomerID
    FROM Bookings
    GROUP BY CustomerID
    ORDER BY SUM(TotalAmount) DESC
    LIMIT 1
);

-- Q151
SELECT *
FROM Rooms
WHERE RoomID NOT IN (
    SELECT RoomID
    FROM Bookings
    WHERE YEAR(CheckInDate) = 2024
);

-- Q152
SELECT *
FROM Staff
WHERE StaffID NOT IN (
    SELECT StaffID
    FROM Bookings
    WHERE YEAR(CheckInDate) = 2024
);

-- Q153
SELECT *
FROM Customers
WHERE CustomerID NOT IN (
    SELECT CustomerID
    FROM Bookings
    WHERE YEAR(CheckInDate) = 2024
);

-- Q154
SELECT *
FROM Bookings
WHERE MONTH(CheckInDate) = (
    SELECT MONTH(CheckInDate)
    FROM Bookings
    GROUP BY MONTH(CheckInDate)
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

-- Q155
SELECT *
FROM Payments
WHERE PaymentMethod = (
    SELECT PaymentMethod
    FROM Payments
    GROUP BY PaymentMethod
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

-- Q156
SELECT *
FROM Rooms
WHERE Capacity = (
    SELECT MIN(Capacity) FROM Rooms
);

-- Q157
SELECT *
FROM Staff
WHERE Role = (
    SELECT Role
    FROM Staff
    GROUP BY Role
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

-- Q158
SELECT *
FROM Customers
WHERE City = (
    SELECT City
    FROM Customers
    GROUP BY City
    ORDER BY COUNT(*) ASC
    LIMIT 1
);

-- Q159
SELECT *
FROM Bookings
WHERE TotalAmount < (
    SELECT AVG(TotalAmount) FROM Bookings
);

-- Q160
SELECT *
FROM Payments
WHERE Amount > (
    SELECT AVG(Amount) FROM Payments
);




-- Q161
ALTER TABLE Customers ADD Gender VARCHAR(10);

-- Q162
ALTER TABLE Rooms ADD Status VARCHAR(20);

-- Q163
ALTER TABLE Staff ADD Salary DECIMAL(10,2);

-- Q164
UPDATE Rooms SET Status = 'Available';

-- Q165
UPDATE Staff SET Salary = Salary * 1.10 WHERE Role = 'Manager';

-- Q166
DELETE FROM Payments WHERE Amount < 500;

-- Q167
DELETE FROM Bookings WHERE CheckOutDate < '2023-01-01';

-- Q168
DELETE FROM Customers
WHERE CustomerID NOT IN (SELECT CustomerID FROM Bookings);

-- Q169
CREATE INDEX idx_customer_city ON Customers(City);

-- Q170
CREATE INDEX idx_room_type ON Rooms(RoomType);

-- Q171
DROP VIEW IF EXISTS Staff_Contact_Details;

-- Q172
CREATE VIEW Booking_Details AS
SELECT B.BookingID, C.FirstName, R.RoomType, B.TotalAmount
FROM Bookings B
JOIN Customers C ON B.CustomerID = C.CustomerID
JOIN Rooms R ON B.RoomID = R.RoomID;

-- Q173
CREATE VIEW Payment_Details AS
SELECT P.PaymentID, P.PaymentMethod, P.Amount, B.BookingID
FROM Payments P
JOIN Bookings B ON P.BookingID = B.BookingID;

-- Q174
CREATE TRIGGER before_booking_insert
BEFORE INSERT ON Bookings
FOR EACH ROW
SET NEW.TotalAmount = 0;

-- Q175
CREATE TRIGGER after_payment_insert
AFTER INSERT ON Payments
FOR EACH ROW
UPDATE Bookings
SET TotalAmount = TotalAmount + NEW.Amount
WHERE BookingID = NEW.BookingID;

-- Q176
SELECT *
FROM Booking_Details
WHERE TotalAmount > 5000;

-- Q177
SELECT *
FROM Payment_Details
WHERE PaymentMethod = 'UPI';

-- Q178
DROP INDEX idx_customer_city ON Customers;

-- Q179
DROP INDEX idx_room_type ON Rooms;

-- Q180
ALTER TABLE Staff DROP COLUMN Salary;



-- Q181
SELECT DATABASE();

-- Q182
SHOW TABLES;

-- Q183
DESCRIBE Customers;

-- Q184
DESCRIBE Rooms;

-- Q185
DESCRIBE Staff;

-- Q186
DESCRIBE Bookings;

-- Q187
DESCRIBE Payments;

-- Q188
SELECT NOW();

-- Q189
SELECT CURDATE();

-- Q190
SELECT CURTIME();

-- Q191
SELECT VERSION();

-- Q192
SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'HotelManagement';

-- Q193
SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'HotelManagement'
AND TABLE_NAME = 'Customers';

-- Q194
SELECT USER();

-- Q195
SHOW CREATE TABLE Customers;

-- Q196
SHOW CREATE TABLE Rooms;

-- Q197
SHOW CREATE TABLE Staff;

-- Q198
SHOW CREATE TABLE Bookings;

-- Q199
SHOW CREATE TABLE Payments;

-- Q200
SELECT @@datadir;

-- Q201
SELECT @@hostname;

-- Q202
SELECT @@port;

-- Q203
SHOW VARIABLES LIKE 'version%';

-- Q204
SHOW STATUS LIKE 'Threads_connected';

-- Q205
SELECT TABLE_NAME, TABLE_ROWS
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'HotelManagement';

-- Q206
SELECT TABLE_NAME, ENGINE
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'HotelManagement';

-- Q207
SELECT COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'HotelManagement'
AND TABLE_NAME = 'Bookings';

-- Q208
SELECT 'Hotel Management System Project Completed Successfully' AS Status;

