SELECT * FROM Employees WHERE DepartmentID = 3;
SELECT * FROM Employees WHERE Salary > 60000;
