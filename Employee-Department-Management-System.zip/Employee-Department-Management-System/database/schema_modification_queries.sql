ALTER TABLE Employees ADD MaritalStatus VARCHAR(20);
