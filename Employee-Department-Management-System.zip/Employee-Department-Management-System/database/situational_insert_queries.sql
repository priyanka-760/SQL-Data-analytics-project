INSERT INTO Employees (FirstName, LastName, DepartmentID, Salary, DateOfJoining, Email)
VALUES ('Siddharth','Gupta',3,70000,'2024-01-01','siddharth.gupta@example.com');
