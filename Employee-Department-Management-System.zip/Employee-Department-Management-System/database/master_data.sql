INSERT INTO Departments (DepartmentName, Location, HeadOfDepartment, AnnualBudget) VALUES
('HR','Pune','Raj Sharma',500000),
('Finance','Mumbai','Sneha Gupta',1000000),
('IT','Bangalore','Anil Kumar',1500000);

INSERT INTO Employees (FirstName, LastName, DepartmentID, Salary, DateOfJoining, Email) VALUES
('Ravi','Sharma',1,45000,'2022-05-20','ravi.sharma@example.com'),
('Priya','Patil',2,60000,'2021-03-15','priya.patil@example.com'),
('Amit','Kumar',3,75000,'2020-01-10','amit.kumar@example.com');
