SELECT DepartmentID, COUNT(*) FROM Employees GROUP BY DepartmentID;
