UPDATE Employees SET Salary = Salary * 1.10 WHERE DepartmentID = 3;
