SELECT CONCAT(FirstName,' ',LastName) AS FullName FROM Employees;
