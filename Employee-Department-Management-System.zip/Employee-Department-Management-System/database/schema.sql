CREATE DATABASE EmployeeManagement;
USE EmployeeManagement;

CREATE TABLE Departments (
 DepartmentID INT PRIMARY KEY AUTO_INCREMENT,
 DepartmentName VARCHAR(50) NOT NULL,
 Location VARCHAR(50),
 HeadOfDepartment VARCHAR(50),
 AnnualBudget DECIMAL(10,2)
);

CREATE TABLE Employees (
 EmployeeID INT PRIMARY KEY AUTO_INCREMENT,
 FirstName VARCHAR(50) NOT NULL,
 LastName VARCHAR(50),
 DepartmentID INT,
 Salary DECIMAL(10,2),
 DateOfJoining DATE,
 Email VARCHAR(100) UNIQUE NOT NULL,
 FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID)
);
