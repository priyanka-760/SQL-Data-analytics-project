DELETE FROM Employees WHERE Salary < 30000;
